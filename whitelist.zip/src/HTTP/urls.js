export const WHITELIST_APIs_BASE_URL =
  "https://whitelist-backend-server.herokuapp.com";
