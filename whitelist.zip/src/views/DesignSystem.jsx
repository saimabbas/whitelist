import React from "react";

const DesignSystem = () => {
  return (
    <div className="design-system">
      <h1>Heading 1 - 64px </h1>
    </div>
  );
};

export default DesignSystem;
