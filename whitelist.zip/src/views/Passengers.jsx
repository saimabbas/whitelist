import React from "react";

const Passengers = () => {
  return <div>Passengers</div>;
};

export default Passengers;
